# Installation
> `npm install --save @types/whatwg-url`

# Summary
This package contains type definitions for whatwg-url (https://github.com/jsdom/whatwg-url#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/whatwg-url.

### Additional Details
 * Last updated: Tue, 21 Jun 2022 16:31:40 GMT
 * Dependencies: [@types/webidl-conversions](https://npmjs.com/package/@types/webidl-conversions), [@types/node](https://npmjs.com/package/@types/node)
 * Global values: none

# Credits
These definitions were written by [Alexander Marks](https://github.com/aomarks), and [ExE Boss](https://github.com/ExE-Boss).
